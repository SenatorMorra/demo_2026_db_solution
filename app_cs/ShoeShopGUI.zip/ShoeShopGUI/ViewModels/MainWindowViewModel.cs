using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using ShoeShopGUI.Models;
using ShoeShopGUI.Services;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System;
using System.Linq;

namespace ShoeShopGUI.ViewModels;

public partial class MainWindowViewModel : ViewModelBase
{
    private readonly DatabaseServiceSimple _databaseService;
    private User? _currentUser;

    public event EventHandler? LogoutRequested;

    [ObservableProperty]
    private ObservableCollection<Product> _products = new();

    [ObservableProperty]
    private Product? _selectedProduct;

    [ObservableProperty]
    private string _searchText = string.Empty;

    [ObservableProperty]
    private string _statusMessage = "Загрузка товаров...";

    [ObservableProperty]
    private bool _isLoading = false;

    public User? CurrentUser
    {
        get => _currentUser;
        private set
        {
            SetProperty(ref _currentUser, value);
            OnPropertyChanged(nameof(CanManageOrders));
            OnPropertyChanged(nameof(IsLoggedIn));
            OnPropertyChanged(nameof(UserDisplayName));
        }
    }

    public bool CanManageOrders => CurrentUser != null && (CurrentUser.IsManager || CurrentUser.IsAdmin);
    public bool IsLoggedIn => CurrentUser != null;
    public string UserDisplayName => CurrentUser?.FullName ?? "Гость";

    public MainWindowViewModel(DatabaseServiceSimple databaseService)
    {
        _databaseService = databaseService;
        _ = LoadProductsAsync();
    }

    private async Task LoadProductsAsync()
    {
        try
        {
            IsLoading = true;
            StatusMessage = "Загрузка товаров из базы данных...";

            var products = await _databaseService.GetProductsAsync();
            Console.WriteLine($"Database вернул {products.Count} товаров");

            Products.Clear();
            foreach (var product in products)
            {
                Console.WriteLine($"Добавление товара: {product.ProductName} - {product.Price}");
                Products.Add(product);
            }

            StatusMessage = $"Загружено {Products.Count} товаров";
            Console.WriteLine($"В ObservableCollection {Products.Count} товаров");
        }
        catch (Exception ex)
        {
            StatusMessage = $"Ошибка загрузки: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    [RelayCommand]
    private async Task SearchProducts()
    {
        try
        {
            IsLoading = true;
            StatusMessage = "Поиск товаров...";

            var allProducts = await _databaseService.GetProductsAsync();
            var filteredProducts = string.IsNullOrWhiteSpace(SearchText)
                ? allProducts
                : allProducts.Where(p =>
                    p.ProductName.ToLower().Contains(SearchText.ToLower()) ||
                    p.ArticleNumber.ToLower().Contains(SearchText.ToLower()) ||
                    (p.Category?.CategoryName?.ToLower().Contains(SearchText.ToLower()) ?? false))
                .ToList();

            Products.Clear();
            foreach (var product in filteredProducts)
            {
                Products.Add(product);
            }

            StatusMessage = $"Найдено {Products.Count} товаров";
        }
        catch (Exception ex)
        {
            StatusMessage = $"Ошибка поиска: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    [RelayCommand]
    private async Task ShowLoginDialog()
    {
        //TODO: Implement login dialog
        await Task.CompletedTask;
    }

    [RelayCommand]
    private void Logout()
    {
        CurrentUser = null;
        StatusMessage = "Вы вышли из системы";
        LogoutRequested?.Invoke(this, EventArgs.Empty);
    }

    [RelayCommand]
    private async Task RefreshProducts()
    {
        SearchText = string.Empty;
        await LoadProductsAsync();
    }

    [RelayCommand]
    private void ShowOrders()
    {
        //TODO: Implement orders window
        StatusMessage = "Управление заказами (в разработке)";
    }

    public void SetCurrentUser(User user)
    {
        CurrentUser = user;
        StatusMessage = $"Вы вошли как: {user.FullName}";
    }
}