﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace ShoeShopGUI.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
