using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using ShoeShopGUI.Models;
using ShoeShopGUI.Services;
using System.Threading.Tasks;
using System.Windows.Input;
using System;

namespace ShoeShopGUI.ViewModels;

public partial class LoginWindowViewModel : ViewModelBase
{
    private readonly DatabaseServiceSimple _databaseService;

    [ObservableProperty]
    private string _userLogin = string.Empty;

    [ObservableProperty]
    private string _password = string.Empty;

    [ObservableProperty]
    private string _errorMessage = string.Empty;

    [ObservableProperty]
    private bool _hasErrorMessage = false;

    public User? CurrentUser { get; private set; }

    public event EventHandler<User?>? LoginSuccessful;

    public LoginWindowViewModel(DatabaseServiceSimple databaseService)
    {
        _databaseService = databaseService;
    }

    [RelayCommand]
    private async Task Login()
    {
        try
        {
            // Проверка на пустые поля
            if (string.IsNullOrWhiteSpace(UserLogin) || string.IsNullOrWhiteSpace(Password))
            {
                ShowError("Пожалуйста, введите логин и пароль");
                return;
            }

            // Попытка авторизации
            var user = await _databaseService.AuthenticateUserAsync(UserLogin, Password);

            if (user != null)
            {
                CurrentUser = user;
                ClearError();
                LoginSuccessful?.Invoke(this, user);
            }
            else
            {
                ShowError("Неверный логин или пароль");
            }
        }
        catch (Exception ex)
        {
            ShowError($"Ошибка при входе: {ex.Message}");
        }
    }

    [RelayCommand]
    private void LoginAsGuest()
    {
        try
        {
            Console.WriteLine("LoginAsGuest command triggered!");

            // Создаем пользователя-гостя
            CurrentUser = new User
            {
                Id = 0,
                Login = "guest",
                FirstName = "Гость",
                LastName = "",
                Role = new Role { RoleName = "Гость" }
            };

            ClearError();
            Console.WriteLine($"Guest user created: {CurrentUser.FirstName}");
            LoginSuccessful?.Invoke(this, CurrentUser);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error in LoginAsGuest: {ex.Message}");
            ShowError($"Ошибка при входе как гость: {ex.Message}");
        }
    }

    private void ShowError(string message)
    {
        ErrorMessage = message;
        HasErrorMessage = true;
    }

    private void ClearError()
    {
        ErrorMessage = string.Empty;
        HasErrorMessage = false;
    }
}