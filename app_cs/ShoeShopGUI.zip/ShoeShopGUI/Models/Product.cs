using System;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using System.IO;

namespace ShoeShopGUI.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string ArticleNumber { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public string Unit { get; set; } = "шт.";
        public int StockQuantity { get; set; }
        public decimal DiscountPercent { get; set; }
        public string? Description { get; set; }
        public string? PhotoUrl { get; set; }
        public int CategoryId { get; set; }
        public int SupplierId { get; set; }
        public int ManufacturerId { get; set; }

        public Category? Category { get; set; }
        public Supplier? Supplier { get; set; }
        public Manufacturer? Manufacturer { get; set; }

        // Плоские свойства для DataGrid
        public string? CategoryName { get; set; }
        public string? SupplierName { get; set; }
        public string? ManufacturerName { get; set; }

        // Путь к изображению (используем абсолютные пути)
        public string? ImagePath
        {
            get
            {
                // Если фото_url пустой или null, возвращаем заглушку
                if (string.IsNullOrWhiteSpace(PhotoUrl))
                {
                    return "Assets/picture.png";
                }

                // Используем относительный путь
                var path = $"Assets/{PhotoUrl}";
                return path;
            }
        }

        // Свойство для отладки - проверяем URL фото
        public string? PhotoUrlDebug => PhotoUrl;

        // Bitmap для отображения в Image
        public Bitmap? ProductImage
        {
            get
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(PhotoUrl))
                    {
                        // Заглушка
                        try
                        {
                            return new Bitmap("Assets/picture.png");
                        }
                        catch
                        {
                            return null;
                        }
                    }

                    try
                    {
                        var imagePath = $"Assets/{PhotoUrl}";
                        var bitmap = new Bitmap(imagePath);
                        return bitmap;
                    }
                    catch
                    {
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error loading image for {ProductName}: {ex.Message}");
                    return null;
                }
            }
        }

        public decimal DiscountedPrice
        {
            get
            {
                if (DiscountPercent > 0)
                    return Price * (1 - DiscountPercent / 100);
                return Price;
            }
        }

        public string AvailabilityStatus
        {
            get
            {
                if (StockQuantity == 0) return "Нет в наличии";
                if (StockQuantity <= 5) return "Мало в наличии";
                return "В наличии";
            }
        }

        public bool HasDiscount => DiscountPercent > 0;
        public bool HasHighDiscount => DiscountPercent > 15;

        public string BackgroundColor
        {
            get
            {
                if (StockQuantity == 0) return "#87CEEB"; // Голубой - нет на складе
                if (HasHighDiscount) return "#2E8B57"; // Зеленый - высокая скидка
                return "White"; // Белый - обычный
            }
        }

        public override string ToString()
        {
            return $"{ProductName} ({ArticleNumber}) - {Price:C}";
        }
    }

    public class Category
    {
        public int Id { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public override string ToString() => CategoryName;
    }

    public class Supplier
    {
        public int Id { get; set; }
        public string SupplierName { get; set; } = string.Empty;
        public override string ToString() => SupplierName;
    }

    public class Manufacturer
    {
        public int Id { get; set; }
        public string ManufacturerName { get; set; } = string.Empty;
        public override string ToString() => ManufacturerName;
    }
}