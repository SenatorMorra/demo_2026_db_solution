using MySql.Data.MySqlClient;
using ShoeShopGUI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace ShoeShopGUI.Services
{
    public class DatabaseServiceSimple
    {
        private readonly string _connectionString;

        public DatabaseServiceSimple(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                ?? throw new InvalidOperationException("Строка подключения не найдена");
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(_connectionString);
        }

        public async Task<User?> AuthenticateUserAsync(string login, string password)
        {
            try
            {
                using var connection = GetConnection();
                await connection.OpenAsync();

                var query = @"
                    SELECT u.*, r.role_name
                    FROM users u
                    JOIN roles r ON u.id_role = r.id_role
                    WHERE u.login = @login AND u.password_hash = @password";

                using var command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@login", login);
                command.Parameters.AddWithValue("@password", password);

                using var reader = await command.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    return new User
                    {
                        Id = reader.GetInt32(0), // id_user
                        LastName = reader.GetString(1), // last_name
                        FirstName = reader.GetString(2), // first_name
                        MiddleName = reader.IsDBNull(3) ? null : reader.GetString(3), // middle_name
                        Login = reader.GetString(4), // login
                        PasswordHash = reader.GetString(5), // password_hash
                        RoleId = reader.GetInt32(6), // id_role
                        Role = new Role
                        {
                            Id = reader.GetInt32(6),
                            RoleName = reader.GetString(7) // role_name
                        }
                    };
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при авторизации: {ex.Message}");
            }

            return null;
        }

        public async Task<List<Product>> GetProductsAsync()
        {
            var products = new List<Product>();

            try
            {
                using var connection = GetConnection();
                await connection.OpenAsync();

                var query = @"
                    SELECT p.*, c.category_name, s.supplier_name, m.manufacturer_name
                    FROM products p
                    LEFT JOIN categories c ON p.id_category = c.id_category
                    LEFT JOIN suppliers s ON p.id_supplier = s.id_supplier
                    LEFT JOIN manufacturers m ON p.id_manufacturer = m.id_manufacturer
                    ORDER BY p.product_name";

                using var command = new MySqlCommand(query, connection);
                using var reader = await command.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    var product = new Product
                    {
                        Id = reader.GetInt32(0), // id_product
                        ArticleNumber = reader.GetString(1), // article_number
                        ProductName = reader.GetString(2), // product_name
                        Price = reader.GetDecimal(3), // price
                        Unit = reader.GetString(4), // unit
                        StockQuantity = reader.GetInt32(5), // stock_quantity
                        DiscountPercent = reader.IsDBNull(6) ? 0 : reader.GetDecimal(6), // discount_percent
                        Description = reader.IsDBNull(7) ? null : reader.GetString(7), // description
                        PhotoUrl = reader.IsDBNull(8) ? null : reader.GetString(8), // photo_url
                        CategoryId = reader.GetInt32(9), // id_category
                        SupplierId = reader.GetInt32(10), // id_supplier
                        ManufacturerId = reader.GetInt32(11), // id_manufacturer

                        // Плоские свойства для прямого отображения в DataGrid
                        CategoryName = reader.IsDBNull(12) ? null : reader.GetString(12), // category_name
                        SupplierName = reader.IsDBNull(13) ? null : reader.GetString(13), // supplier_name
                        ManufacturerName = reader.IsDBNull(14) ? null : reader.GetString(14), // manufacturer_name

                        Category = new Category
                        {
                            CategoryName = reader.IsDBNull(12) ? "" : reader.GetString(12)
                        },
                        Supplier = new Supplier
                        {
                            SupplierName = reader.IsDBNull(13) ? "" : reader.GetString(13)
                        },
                        Manufacturer = new Manufacturer
                        {
                            ManufacturerName = reader.IsDBNull(14) ? "" : reader.GetString(14)
                        }
                    };
                    products.Add(product);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при получении товаров: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
            }

            return products;
        }

        public async Task<bool> TestConnectionAsync()
        {
            try
            {
                using var connection = GetConnection();
                await connection.OpenAsync();
                var query = "SELECT 1";
                using var command = new MySqlCommand(query, connection);
                await command.ExecuteScalarAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}