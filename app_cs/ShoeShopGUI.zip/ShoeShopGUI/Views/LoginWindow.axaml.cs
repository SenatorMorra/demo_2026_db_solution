using Avalonia.Controls;
using Avalonia.Interactivity;
using ShoeShopGUI.ViewModels;
using ShoeShopGUI.Models;
using ShoeShopGUI.Services;
using Microsoft.Extensions.DependencyInjection;

namespace ShoeShopGUI.Views;

public partial class LoginWindow : Window
{
    public LoginWindow(DatabaseServiceSimple databaseService)
    {
        InitializeComponent();

        // Устанавливаем DataContext
        var viewModel = new LoginWindowViewModel(databaseService);
        DataContext = viewModel;

        // Подписываемся на событие успешной авторизации
        viewModel.LoginSuccessful += OnLoginSuccessful;
    }

    private void OnLoginSuccessful(object? sender, User? user)
    {
        if (user != null)
        {
            // Открываем главное окно
            var mainWindow = new MainWindow();
            mainWindow.SetCurrentUser(user);
            mainWindow.Show();

            // Закрываем окно входа
            this.Close();
        }
    }
}