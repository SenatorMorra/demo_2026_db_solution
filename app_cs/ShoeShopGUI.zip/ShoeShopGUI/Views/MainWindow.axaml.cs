using System;
using Avalonia.Controls;
using ShoeShopGUI.Models;
using ShoeShopGUI.ViewModels;
using ShoeShopGUI.Services;
using Microsoft.Extensions.Configuration;

namespace ShoeShopGUI.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    public void SetCurrentUser(User user)
    {
        // Create configuration and database service
        var configuration = new ConfigurationBuilder()
            .SetBasePath(System.IO.Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        var databaseService = new DatabaseServiceSimple(configuration);

        // Set DataContext with user
        var viewModel = new MainWindowViewModel(databaseService);
        DataContext = viewModel;
        viewModel.SetCurrentUser(user);

        // Подписываемся на событие выхода
        viewModel.LogoutRequested += OnLogoutRequested;

        // Update window title with user info
        Title = $"🏪 Обувной магазин - {user.FirstName} ({user.Role?.RoleName})";
    }

    private void OnLogoutRequested(object? sender, EventArgs e)
    {
        // Открываем окно входа
        var configuration = new ConfigurationBuilder()
            .SetBasePath(System.IO.Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        var databaseService = new DatabaseServiceSimple(configuration);
        var loginWindow = new LoginWindow(databaseService);
        loginWindow.Show();

        // Закрываем главное окно
        this.Close();
    }
}