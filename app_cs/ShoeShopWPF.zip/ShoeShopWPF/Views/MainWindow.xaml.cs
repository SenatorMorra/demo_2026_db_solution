using System;
using System.Windows;
using ShoeShopWPF.Models;
using ShoeShopWPF.Services;
using ShoeShopWPF.ViewModels;
using Microsoft.Extensions.Configuration;

namespace ShoeShopWPF.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Устанавливаем DataContext
            var databaseService = App.GetService<DatabaseServiceSimple>();
            var viewModel = new MainWindowViewModel(databaseService);
            DataContext = viewModel;

            // Подписываемся на событие выхода
            viewModel.LogoutRequested += OnLogoutRequested;
        }

        public async void SetCurrentUser(User user)
        {
            if (DataContext is MainWindowViewModel viewModel)
            {
                await viewModel.InitializeAsync();
                viewModel.SetCurrentUser(user);

                // Обновляем заголовок окна
                Title = $"🏪 Обувной магазин - {user.FirstName} ({user.Role?.RoleName})";
            }
        }

        private void OnLogoutRequested(object? sender, EventArgs e)
        {
            // Открываем окно входа
            var loginWindow = new LoginWindow();
            loginWindow.Show();

            // Закрываем главное окно
            this.Close();
        }
    }
}