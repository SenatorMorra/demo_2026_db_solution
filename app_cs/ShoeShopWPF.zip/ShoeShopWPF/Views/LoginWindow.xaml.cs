using System;
using System.Windows;
using System.Windows.Controls;
using ShoeShopWPF.Models;
using ShoeShopWPF.Services;
using ShoeShopWPF.ViewModels;

namespace ShoeShopWPF.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();

            // Устанавливаем DataContext
            var databaseService = App.GetService<DatabaseServiceSimple>();
            var viewModel = new LoginWindowViewModel(databaseService);
            DataContext = viewModel;

            // Подписываемся на событие успешной авторизации
            viewModel.LoginSuccessful += OnLoginSuccessful;
        }

        private void OnLoginSuccessful(object? sender, User? user)
        {
            if (user != null)
            {
                // Открываем главное окно
                var mainWindow = new MainWindow();
                mainWindow.SetCurrentUser(user);
                mainWindow.Show();

                // Закрываем окно входа
                this.Close();
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is LoginWindowViewModel viewModel)
            {
                viewModel.Password = ((PasswordBox)sender).Password;
            }
        }
    }
}