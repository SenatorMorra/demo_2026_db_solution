using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using ShoeShopWPF.Models;
using ShoeShopWPF.Services;

namespace ShoeShopWPF.ViewModels
{
    public class LoginWindowViewModel : ViewModelBase
    {
        private readonly DatabaseServiceSimple _databaseService;

        private string _userLogin = string.Empty;
        private string _password = string.Empty;
        private string _errorMessage = string.Empty;
        private bool _hasErrorMessage = false;
        private bool _isLoading = false;

        public string UserLogin
        {
            get => _userLogin;
            set => SetProperty(ref _userLogin, value);
        }

        public string Password
        {
            get => _password;
            set => SetProperty(ref _password, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        public bool HasErrorMessage
        {
            get => _hasErrorMessage;
            set => SetProperty(ref _hasErrorMessage, value);
        }

        public bool IsLoading
        {
            get => _isLoading;
            set => SetProperty(ref _isLoading, value);
        }

        public User? CurrentUser { get; private set; }

        public event EventHandler<User?>? LoginSuccessful;

        public ICommand LoginCommand { get; }
        public ICommand LoginAsGuestCommand { get; }

        public LoginWindowViewModel(DatabaseServiceSimple databaseService)
        {
            _databaseService = databaseService;
            LoginCommand = new RelayCommand(async _ => await Login(), _ => !IsLoading);
            LoginAsGuestCommand = new RelayCommand(LoginAsGuest, _ => !IsLoading);
        }

        private async Task Login()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(UserLogin) || string.IsNullOrWhiteSpace(Password))
                {
                    ShowError("Пожалуйста, введите логин и пароль");
                    return;
                }

                IsLoading = true;
                ErrorMessage = string.Empty;
                HasErrorMessage = false;

                var user = await _databaseService.AuthenticateUserAsync(UserLogin, Password);

                if (user != null)
                {
                    CurrentUser = user;
                    ClearError();
                    LoginSuccessful?.Invoke(this, user);
                }
                else
                {
                    ShowError("Неверный логин или пароль");
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка при входе: {ex.Message}");
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void LoginAsGuest()
        {
            try
            {
                CurrentUser = new User
                {
                    Id = 0,
                    Login = "guest",
                    FirstName = "Гость",
                    LastName = "",
                    Role = new Role { RoleName = "Гость" }
                };

                ClearError();
                LoginSuccessful?.Invoke(this, CurrentUser);
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка при входе как гость: {ex.Message}");
            }
        }

        private void ShowError(string message)
        {
            ErrorMessage = message;
            HasErrorMessage = true;
        }

        private void ClearError()
        {
            ErrorMessage = string.Empty;
            HasErrorMessage = false;
        }
    }
}