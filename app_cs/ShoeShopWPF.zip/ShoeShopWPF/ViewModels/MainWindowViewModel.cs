using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using ShoeShopWPF.Models;
using ShoeShopWPF.Services;

namespace ShoeShopWPF.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        private readonly DatabaseServiceSimple _databaseService;
        private User? _currentUser;
        private ObservableCollection<Product> _products = new();
        private Product? _selectedProduct;
        private string _searchText = string.Empty;
        private string _statusMessage = "Загрузка товаров...";
        private bool _isLoading = false;

        public User? CurrentUser
        {
            get => _currentUser;
            private set
            {
                if (SetProperty(ref _currentUser, value))
                {
                    OnPropertyChanged(nameof(CanManageProducts));
                    OnPropertyChanged(nameof(IsLoggedIn));
                    OnPropertyChanged(nameof(UserDisplayName));
                }
            }
        }

        public ObservableCollection<Product> Products
        {
            get => _products;
            set => SetProperty(ref _products, value);
        }

        public Product? SelectedProduct
        {
            get => _selectedProduct;
            set => SetProperty(ref _selectedProduct, value);
        }

        public string SearchText
        {
            get => _searchText;
            set => SetProperty(ref _searchText, value);
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set => SetProperty(ref _statusMessage, value);
        }

        public bool IsLoading
        {
            get => _isLoading;
            set => SetProperty(ref _isLoading, value);
        }

        public bool CanManageProducts => CurrentUser?.IsAdmin == true;
        public bool IsLoggedIn => CurrentUser != null;
        public string UserDisplayName => CurrentUser?.FullName ?? "Гость";

        public ICommand LoadProductsCommand { get; }
        public ICommand SearchProductsCommand { get; }
        public ICommand RefreshProductsCommand { get; }
        public ICommand LogoutCommand { get; }

        public event EventHandler? LogoutRequested;

        public MainWindowViewModel(DatabaseServiceSimple databaseService)
        {
            _databaseService = databaseService;
            LoadProductsCommand = new RelayCommand(async _ => await LoadProductsAsync(), _ => !IsLoading);
            SearchProductsCommand = new RelayCommand(async _ => await SearchProducts(), _ => !IsLoading);
            RefreshProductsCommand = new RelayCommand(async _ => await RefreshProductsAsync(), _ => !IsLoading);
            LogoutCommand = new RelayCommand(Logout);
        }

        public async Task InitializeAsync()
        {
            await LoadProductsAsync();
        }

        private async Task LoadProductsAsync()
        {
            try
            {
                IsLoading = true;
                StatusMessage = "Загрузка товаров...";

                var products = await _databaseService.GetProductsAsync();

                Products.Clear();
                foreach (var product in products)
                {
                    Products.Add(product);
                }

                StatusMessage = $"Загружено {Products.Count} товаров";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки: {ex.Message}";
                MessageBox.Show($"Ошибка при загрузке товаров: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                IsLoading = false;
            }
        }

        private async Task SearchProducts()
        {
            try
            {
                IsLoading = true;
                StatusMessage = "Поиск товаров...";

                var allProducts = await _databaseService.GetProductsAsync();
                var filteredProducts = string.IsNullOrWhiteSpace(SearchText)
                    ? allProducts
                    : allProducts.Where(p =>
                        p.ProductName.ToLower().Contains(SearchText.ToLower()) ||
                        p.ArticleNumber.ToLower().Contains(SearchText.ToLower()) ||
                        (p.CategoryName?.ToLower().Contains(SearchText.ToLower()) ?? false))
                    .ToList();

                Products.Clear();
                foreach (var product in filteredProducts)
                {
                    Products.Add(product);
                }

                StatusMessage = $"Найдено {Products.Count} товаров";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка поиска: {ex.Message}";
                MessageBox.Show($"Ошибка при поиске товаров: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                IsLoading = false;
            }
        }

        private async Task RefreshProductsAsync()
        {
            SearchText = string.Empty;
            await LoadProductsAsync();
        }

        private void Logout()
        {
            CurrentUser = null;
            StatusMessage = "Вы вышли из системы";
            LogoutRequested?.Invoke(this, EventArgs.Empty);
        }

        public void SetCurrentUser(User user)
        {
            CurrentUser = user;
            StatusMessage = $"Вы вошли как: {user.FullName} ({user.Role?.RoleName})";
        }
    }
}