using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Windows;
using ShoeShopWPF.Services;

namespace ShoeShopWPF
{
    class Program
    {
        [STAThread]
        public static void Main(string[] args)
        {
            using var host = CreateHostBuilder(args).Build();
            var app = new App();
            app.InitializeComponent();
            app.Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureServices((context, services) =>
                {
                    services.AddSingleton<DatabaseServiceSimple>();
                });
    }
}