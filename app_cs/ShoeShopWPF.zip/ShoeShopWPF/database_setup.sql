-- =====================================================
-- 🏪 Обувной магазин - Скрипт установки базы данных
-- =====================================================

-- Создание базы данных (если не существует)
CREATE DATABASE IF NOT EXISTS shoe_store
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE shoe_store;

-- =====================================================
-- 📋 Таблицы справочников
-- =====================================================

-- Таблица ролей пользователей
CREATE TABLE IF NOT EXISTS roles (
    id_role INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Таблица категорий товаров
CREATE TABLE IF NOT EXISTS categories (
    id_category INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Таблица производителей
CREATE TABLE IF NOT EXISTS manufacturers (
    id_manufacturer INT PRIMARY KEY AUTO_INCREMENT,
    manufacturer_name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Таблица поставщиков
CREATE TABLE IF NOT EXISTS suppliers (
    id_supplier INT PRIMARY KEY AUTO_INCREMENT,
    supplier_name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- 👥 Таблицы пользователей
-- =====================================================

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
    id_user INT PRIMARY KEY AUTO_INCREMENT,
    login VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100),
    id_role INT,
    FOREIGN KEY (id_role) REFERENCES roles(id_role) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- 📦 Таблицы товаров
-- =====================================================

-- Таблица товаров
CREATE TABLE IF NOT EXISTS products (
    id_product INT PRIMARY KEY AUTO_INCREMENT,
    article_number VARCHAR(50) NOT NULL UNIQUE,
    product_name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    discount_percent DECIMAL(5,2) DEFAULT 0.00,
    unit VARCHAR(20) NOT NULL DEFAULT 'шт',
    stock_quantity INT NOT NULL DEFAULT 0,
    availability_status VARCHAR(50) NOT NULL DEFAULT 'В наличии',
    photo_url VARCHAR(255),
    id_category INT,
    id_manufacturer INT,
    id_supplier INT,
    FOREIGN KEY (id_category) REFERENCES categories(id_category) ON DELETE SET NULL,
    FOREIGN KEY (id_manufacturer) REFERENCES manufacturers(id_manufacturer) ON DELETE SET NULL,
    FOREIGN KEY (id_supplier) REFERENCES suppliers(id_supplier) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- 📊 Индексы для производительности
-- =====================================================

-- Индексы для поиска
CREATE INDEX idx_products_name ON products(product_name);
CREATE INDEX idx_products_article ON products(article_number);
CREATE INDEX idx_products_category ON products(id_category);
CREATE INDEX idx_products_manufacturer ON products(id_manufacturer);
CREATE INDEX idx_products_price ON products(price);
CREATE INDEX idx_users_login ON users(login);

-- =====================================================
-- 📋 Начальные данные
-- =====================================================

-- Роли пользователей
INSERT IGNORE INTO roles (id_role, role_name) VALUES
(1, 'Администратор'),
(2, 'Менеджер'),
(3, 'Гость');

-- Категории товаров
INSERT IGNORE INTO categories (id_category, category_name) VALUES
(1, 'Ботинки'),
(2, 'Кроссовки'),
(3, 'Туфли'),
(4, 'Сандалии'),
(5, 'Босоножки');

-- Производители
INSERT IGNORE INTO manufacturers (id_manufacturer, manufacturer_name) VALUES
(1, 'Nike'),
(2, 'Adidas'),
(3, 'Marco Tozzi'),
(4, 'Reebok'),
(5, 'Puma'),
(6, 'New Balance');

-- Поставщики
INSERT IGNORE INTO suppliers (id_supplier, supplier_name) VALUES
(1, 'Обувная Компания №1'),
(2, 'Fashion Supplier'),
(3, 'Спортивные Товары'),
(4, 'Евро-Обувь'),
(5, 'Импортер Обуви');

-- Демо-пользователи (пароли в открытом виде - для демонстрации!)
-- В реальном приложении используйте хеширование!
INSERT IGNORE INTO users (id_user, login, password_hash, first_name, last_name, id_role) VALUES
(1, 'admin', 'admin123', 'Администратор', 'Системы', 1),
(2, 'manager', 'manager123', 'Менеджер', 'Продаж', 2),
(3, 'guest', 'guest123', 'Гость', 'Демонстрационный', 3);

-- Демо-товары
INSERT IGNORE INTO products (
    id_product, article_number, product_name, description, price,
    discount_percent, unit, stock_quantity, availability_status,
    photo_url, id_category, id_manufacturer, id_supplier
) VALUES
(1, 'BT001', 'Зимние ботинки', 'Теплые ботинки для зимы с утеплителем', 4599.00, 10.00, 'пара', 25, 'В наличии', '1.jpg', 1, 3, 1),
(2, 'BT002', 'Демисезонные ботинки', 'Удобные ботинки на весну и осень', 3299.00, 0.00, 'пара', 40, 'В наличии', '2.jpg', 1, 4, 2),
(3, 'KR001', 'Спортивные кроссовки', 'Кроссовки для бега и фитнеса', 2799.00, 15.00, 'пара', 60, 'В наличии', '3.jpg', 2, 1, 3),
(4, 'KR002', 'Городские кроссовки', 'Стильные кроссовки для повседневной носки', 2199.00, 0.00, 'пара', 85, 'В наличии', '4.jpg', 2, 2, 4),
(5, 'TF001', 'Классические туфли', 'Элегантные туфли для офиса и мероприятий', 3899.00, 20.00, 'пара', 15, 'В наличии', '5.jpg', 3, 3, 5),
(6, 'TF002', 'Туфли на каблуке', 'Женские туфли на устойчивом каблуке', 2599.00, 0.00, 'пара', 30, 'В наличии', '6.jpg', 3, 6, 1),
(7, 'SD001', 'Летние сандалии', 'Легкие сандалии для жаркой погоды', 1299.00, 10.00, 'пара', 100, 'В наличии', '7.jpg', 4, 5, 2),
(8, 'SD002', 'Детские сандалии', 'Яркие сандалии для детей', 999.00, 0.00, 'пара', 75, 'В наличии', '8.jpg', 4, 1, 3),
(9, 'BB001', 'Женские босоножки', 'Стильные босоножки на лето', 1899.00, 25.00, 'пара', 45, 'В наличии', '9.jpg', 5, 2, 4),
(10, 'BB002', 'Вечерние босоножки', 'Босоножки с декоративными элементами', 3299.00, 0.00, 'пара', 20, 'В наличии', '10.jpg', 5, 3, 5);

-- =====================================================
-- ✅ Проверка установки
-- =====================================================

-- Вывод статистики по созданным данным
SELECT '=== База данных Shoe Store установлена ===' as status;

SELECT
    'Роли пользователей' as table_name,
    COUNT(*) as record_count
FROM roles
UNION ALL
SELECT
    'Категории товаров' as table_name,
    COUNT(*) as record_count
FROM categories
UNION ALL
SELECT
    'Производители' as table_name,
    COUNT(*) as record_count
FROM manufacturers
UNION ALL
SELECT
    'Поставщики' as table_name,
    COUNT(*) as record_count
FROM suppliers
UNION ALL
SELECT
    'Пользователи' as table_name,
    COUNT(*) as record_count
FROM users
UNION ALL
SELECT
    'Товары' as table_name,
    COUNT(*) as record_count
FROM products;

SELECT '=== Готово к работе! ===' as status;