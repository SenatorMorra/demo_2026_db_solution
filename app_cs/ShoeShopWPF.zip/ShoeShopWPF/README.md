# 🏪 Обувной магазин - C# WPF приложение

## 📋 Описание

Приложение на C# и WPF для управления каталогом товаров обувного магазина.

### 🎯 Реализованные модули:
- **Модуль 2:** Просмотр каталога товаров с аутентификацией
- **Модуль 3:** Поиск, фильтрация и CRUD операции с товарами

---

## 🔄 Сравнение с Avalonia версией

| Особенность | Avalonia UI | WPF |
|-------------|-------------|-----|
| **Платформы** | Windows, macOS, Linux | Только Windows |
| **XAML синтаксис** | `<Window xmlns="https://github.com/avaloniaui"` | `<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation">` |
| **Изображения** | `new Bitmap("path")` | `new BitmapImage(new Uri("pack://application:,,,/path"))` |
| **MVVM** | CommunityToolkit.Mvvm | Собственная реализация RelayCommand |
| **Зависимости** | Avalonia packages | WindowsBase, PresentationCore |
| **Ресурсы** | `AvaloniaResource` | `Resource` |

---

## 🛠️ Требования к системе

### **Только для Windows:**
- Windows 10/11
- .NET 8.0 Runtime
- Visual Studio 2022 / JetBrains Rider / VS Code
- MySQL Server

---

## 🚀 Установка и запуск

### **1. Клонирование репозитория:**
```bash
git clone <репозиторий>
cd ShoeShopWPF
```

### **2. Настройка базы данных:**

Выполните SQL скрипт `database_setup.sql` для создания базы данных:

```bash
mysql -u root -p < database_setup.sql
```

### **3. Настройка подключения:**

Откройте файл `appsettings.json` и укажите ваши данные:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=shoe_store;Uid=ВАШ_ЛОГИН;Pwd=ВАШ_ПАРОЛЬ;"
  }
}
```

### **4. Запуск приложения:**

**Через командную строку:**
```bash
dotnet restore
dotnet build
dotnet run
```

**Через Visual Studio:**
1. Откройте файл `ShoeShopWPF.csproj`
2. Нажмите F5

---

## 🏗️ Архитектура WPF

### **Основные отличия от Avalonia:**

1. **Запуск приложения:**
   - **WPF:** `App.xaml` + `App.xaml.cs` + `Program.cs`
   - **Avalonia:** `Program.cs` + `App.axaml`

2. **Обработка изображений:**
   - **WPF:** `BitmapImage` с `pack://application:,,,/` URI
   - **Avalonia:** `Bitmap` с относительными путями

3. **MVVM Commands:**
   - **WPF:** Собственная реализация `RelayCommand`
   - **Avalonia:** `CommunityToolkit.Mvvm` `[RelayCommand]`

4. **XAML синтаксис:**
   - **WPF:** Стандартный синтаксис Microsoft
   - **Avalonia:** Синтаксис Avalonia UI

---

## 📁 Структура проекта

```
ShoeShopWPF/
├── 📁 Models/                    # Модели данных (Product, User, Category)
├── 📁 ViewModels/                # ViewModel классы (MVVM паттерн)
├── 📁 Views/                     # XAML файлы интерфейса
├── 📁 Services/                  # Сервисы работы с базой данных
├── 📁 Assets/                    # Изображения товаров и ресурсы
├── 📄 App.xaml / App.xaml.cs     # 🚪 Точка входа WPF приложения
├── 📄 Program.cs                 # 🚪 Конфигурация DI
├── 📄 database_setup.sql         # 🗄️ Скрипт создания БД
└── 📄 ShoeShopWPF.csproj         # 🔧 Файл проекта
```

---

## 🎯 Функционал

### **Модуль 2 - Просмотр каталога:**
- ✅ Аутентификация пользователей
- ✅ Отображение товаров с фотографиями
- ✅ Информация о товарах (цена, скидки, характеристики)
- ✅ Ролевой доступ к функциям

### **Модуль 3 - Управление товарами:**
- ✅ Поиск товаров по названию, артикулу
- ✅ Сортировка по цене, названию
- ✅ Обновление каталога в реальном времени

---

## 🔧 Конфигурация

### **Файл проекта (.csproj):**
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>WinExe</OutputType>
    <TargetFramework>net8.0-windows</TargetFramework>
    <UseWPF>true</UseWPF>
  </PropertyGroup>
</Project>
```

### **Подключение к базе данных:**
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=ХОСТ;Database=ИМЯ_БД;Uid=ПОЛЬЗОВАТЕЛЬ;Pwd=ПАРОЛЬ;"
  }
}
```

---

## 🛠️ Технологии WPF

- **.NET 8.0 Windows** - последняя версия .NET для Windows
- **WPF (Windows Presentation Foundation)** - нативный UI фреймворк Windows
- **MVVM паттерн** - Собственная реализация RelayCommand
- **MySQL.Data** - коннектор для работы с MySQL
- **Microsoft.Extensions.Configuration** - управление конфигурацией

---

## 🐛 Устранение неполадок WPF

### **Проблема:** Изображения не отображаются
**Решение:** Убедитесь, что изображения скопированы в `Assets/` и помечены как `Resource`.

### **Проблема:** Не работает привязка данных
**Решение:** Проверьте `DataContext` и `INotifyPropertyChanged` реализацию.

### **Проблема:** Команды не выполняются
**Решение:** Проверьте реализацию `ICommand` в `RelayCommand`.

---

## 🎓 Образовательные преимущества

WPF версия показывает студентам:

1. **Нативную Windows разработку**
2. **Классический MVVM без библиотек**
3. **Работу с ресурсами WPF**
4. **Различия фреймворков UI**

---

## 📚 Дополнительная информация

- **Документация по WPF:** https://docs.microsoft.com/dotnet/desktop/wpf/
- **WPF vs Avalonia:** https://avaloniaui.net/docs/guides/wpf-comparison
- **MVVM паттерн:** https://docs.microsoft.com/dotnet/desktop/wpf/data/

---

## 📝 Сравнение кода

### **Загрузка изображений:**
```csharp
// WPF
var bitmap = new BitmapImage();
bitmap.BeginInit();
bitmap.UriSource = new Uri("pack://application:,,,/Assets/photo.jpg");
bitmap.EndInit();

// Avalonia
var bitmap = new Bitmap("Assets/photo.jpg");
```

### **Команды:**
```csharp
// WPF
public class RelayCommand : ICommand { /* собственная реализация */ }

// Avalonia
[RelayCommand]
private void MyCommand() { /* автоматическая генерация */ }
```

---

*📅 Последнее обновление: 20.11.2024*
*👤 Разработчик: Claude Code Assistant*
*🛠️ Технологии: C#, .NET 8.0, WPF, MySQL, MVVM*