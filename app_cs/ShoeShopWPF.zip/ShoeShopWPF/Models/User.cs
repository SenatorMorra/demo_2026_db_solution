using System;

namespace ShoeShopWPF.Models
{
    public class User
    {
        public int Id { get; set; }
        public string LastName { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string? MiddleName { get; set; }
        public string Login { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public int RoleId { get; set; }
        public Role? Role { get; set; }

        public string FullName => $"{LastName} {FirstName} {MiddleName}".Trim();
        public bool IsAdmin => Role?.RoleName == "Администратор";
        public bool IsManager => Role?.RoleName == "Менеджер";
        public bool IsClient => Role?.RoleName == "Авторизированный клиент";

        public override string ToString()
        {
            return $"{FullName} ({Role?.RoleName})";
        }
    }

    public class Role
    {
        public int Id { get; set; }
        public string RoleName { get; set; } = string.Empty;
        public override string ToString() => RoleName;
    }
}